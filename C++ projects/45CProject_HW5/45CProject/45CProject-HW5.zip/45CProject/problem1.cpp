#include <iostream>
#include <vector>
#include <string>
#include "Studentinfo.h"
#include <algorithm>
#include <locale>


using namespace std;

// define a function to compare 2 strings
// using string::compare() to compare two strings
bool compare_name_string(StudentInfo a, StudentInfo b){
	string student_1_name = a.getName();
	string student_2_name = b.getName();
	string student_1_lower = student_1_name;
	string student_2_lower = student_2_name;

	for (int i = 0; i < student_1_name.size(); i++){
		student_1_lower[i] = tolower(student_1_name[i]);
	}
	for (int j = 0; j < student_2_name.size(); j++){
		student_2_lower[j] = tolower(student_2_name[j]);
	}
	
	return student_1_lower.compare(student_2_lower) < 0;
	
}
void problem1(){
	cout << "Problem 1" << endl;
	cout << endl;
	// create various students StudentInfo objects 
	StudentInfo student_1("Steven Gomez", 'D');
	StudentInfo student_2("Johnathan Lam", 'B');
	StudentInfo student_3("jOHNATHAN LAM", 'A');
	StudentInfo student_4("Teresa Truong", 'C');
	StudentInfo student_5("Johnathan Lam", 'A');
	StudentInfo student_6("Aeron Huezon", 'A');
	StudentInfo student_7("aeron Huezon", 'A');

	//create a vector and store these elements
	vector <StudentInfo> student_vector;
	student_vector.push_back(student_1);
	student_vector.push_back(student_2);
	student_vector.push_back(student_3);
	student_vector.push_back(student_4);
	student_vector.push_back(student_5);
	student_vector.push_back(student_6);
	student_vector.push_back(student_7);
	
	//Sorting all the elements in alphabetical order based on name
	sort(student_vector.begin(), student_vector.end(), compare_name_string);

	//Using iterator to access the element in the vector and print out these elements 
	for (vector <StudentInfo>::iterator i = student_vector.begin(); i < student_vector.end(); i++){
		StudentInfo info_student = *i; // dereference to access each studentInfo object
		cout << info_student.getName() << " earns the " << info_student.getGrade() << " grade" << endl; 
	}

}

