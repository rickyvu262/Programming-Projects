#include <map>
#include <vector>

std::map<std::string, std::vector<std::string>> school_map_to_state();