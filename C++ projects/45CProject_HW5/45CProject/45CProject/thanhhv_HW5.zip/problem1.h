void problem1(); // create a simpleclass StudentInfo with grade and name
				 // insert some StudentInfo objects in the vector in lexigraphical order
				 //  print out the elements of the vector with grade and name