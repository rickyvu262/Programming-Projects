void problem2(); // read from input file to store state and school as a map
				 // print out the map to console but sorted by the values (school name)
				 // write to an output file the map with the state sorted and then the school name
				 // ask user to input a state abbreviation and print out all the schools correspond to that state. 