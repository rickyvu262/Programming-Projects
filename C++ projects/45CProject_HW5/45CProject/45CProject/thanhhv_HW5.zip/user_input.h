
#include <string>
#include <map>
#include <vector>

std::string school_names(std::string valid_state, std::map<std::string, std::vector<std::string>> school_dict);
void user_input(std::string input_state, std::map<std::string, std::vector<std::string>> school_dict);
